import './App.css';
import { Ccmform } from './components/Ccmform';

function App() {
  return (
    <>
     <Ccmform />
    </>
  );
}

export default App;
